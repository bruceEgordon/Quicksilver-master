define(
"dojo/cldr/nls/pt/currency", //begin v1.x content
{
	"HKD_displayName": "Dólar de Hong Kong",
	"CHF_displayName": "Franco suíço",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "Dólar canadense",
	"HKD_symbol": "HK$",
	"CNY_displayName": "Yuan chinês",
	"USD_symbol": "US$",
	"AUD_displayName": "Dólar australiano",
	"JPY_displayName": "Iene japonês",
	"CAD_symbol": "CA$",
	"USD_displayName": "Dólar norte-americano",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "Libra esterlina britânica",
	"GBP_symbol": "£",
	"AUD_symbol": "AU$",
	"EUR_displayName": "Euro"
}
//end v1.x content
);